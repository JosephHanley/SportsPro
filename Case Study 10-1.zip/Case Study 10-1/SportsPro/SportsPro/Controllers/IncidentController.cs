﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using SportsPro.Models;


namespace SportsPro.Controllers
{
    public class IncidentController : Controller
    {
        private SportsProContext context { get; set; }

        public IncidentController(SportsProContext ctx)
        {
            context = ctx;
        }

        [Route("incidents")]
        public ViewResult List(string filter, string activeIncident = "all", string activeStatus = "all")
        {
            var model = new IncidentsViewModel
            {
                ActiveIncident = activeIncident,
                ActiveStatus = activeStatus,
                Incidents = context.Incidents.OrderBy(i => i.Title).ToList()
            };


            IQueryable<Incident> query = context.Incidents;
            
            if(filter == "unassigned")
            {
                query = query.Where(i => i.TechnicianID == -1);
            } else if (filter == "open")
            {
                query = query.Where(i => i.DateClosed == null);
            } else if (filter == "all")
            {
                if (activeIncident != "all")
                    query = query.Where(i => i.Title == activeIncident.ToLower());
                if (activeStatus != "all")
                    query = query.Where(i => i.Title == activeStatus.ToLower());
            }

            model.Incidents = query.ToList();
            return View(model);

        }

        [HttpGet]
        public ViewResult Add()
        {
            var model = new AddEditIncidentViewModel
            {
                Customers = context.Customers.OrderBy(c => c.CustomerID).ToList(),
                Products = context.Products.OrderBy(p => p.ProductID).ToList(),
                Technicians = context.Technicians.OrderBy(t => t.TechnicianID).ToList(),
                CurrentIncident = new Incident(),
                OperationType = "Add"
            };
        
            return View("Edit", model);
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var model = new AddEditIncidentViewModel
            {
                Customers = context.Customers.OrderBy(c => c.CustomerID).ToList(),
                Products = context.Products.OrderBy(p => p.ProductID).ToList(),
                Technicians = context.Technicians.OrderBy(t => t.TechnicianID).ToList(),
                CurrentIncident = context.Incidents.Find(id),
                OperationType = "Edit"
            };
            return View("Edit", model);
        }

        [HttpPost]
        public IActionResult Edit(Incident incident) 
        {
            if (ModelState.IsValid)
            {
                if (incident.IncidentID == 0)
                    context.Incidents.Add(incident);
                else
                    context.Incidents.Update(incident);
                context.SaveChanges();
                return RedirectToAction("List", "Incident");
            }
            else
            {
                ViewBag.Title = (incident.IncidentID == 0) ? "Add" : "Edit";
                ViewBag.customers = context.Customers.OrderBy(c => c.CustomerID).ToList();
                ViewBag.products = context.Products.OrderBy(p => p.ProductID).ToList();
                ViewBag.technicians = context.Technicians.OrderBy(t => t.TechnicianID).ToList();
                return View(incident);
            }
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            ViewBag.Title = "Delete";
            ViewBag.customers = context.Customers.OrderBy(c => c.CustomerID).ToList();
            var incident = context.Incidents.Find(id);
            return View(incident);
        }

        [HttpPost]
        public IActionResult Delete(Incident incident)
        {
            context.Incidents.Remove(incident);
            context.SaveChanges();
            return RedirectToAction("List", "Incident");
        }

        [HttpPost]

        public IActionResult Filter(string filter)
        {
            return RedirectToAction("List", new { filter = filter });
        }
    }
}
