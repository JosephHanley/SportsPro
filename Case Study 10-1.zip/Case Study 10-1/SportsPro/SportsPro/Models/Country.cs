﻿namespace SportsPro.Models
{
    public class Country
    {
		public string? CountryID { get; set; }
		public string? Name { get; set; }
    }
}
