﻿namespace SportsPro.Models
{
    public class IncidentsViewModel
    {
        public string ActiveIncident { get; set; }
        public string ActiveStatus { get; set; }

        private List<Incident> incidents;
        public List<Incident> Incidents
        {
            get => incidents;
           
            set
            {
                incidents = value;
                /*
               incidents.Insert(0,
                   new Incident { Title = "all" });Use later */
            }
        }

        public string CheckActiveIncident(string i) =>
            i.ToLower() == ActiveIncident.ToLower() ? "active" : "";
        public string CheckActiveStatus(string i) =>
            i.ToLower() == ActiveStatus.ToLower() ? "active" : "";


    }
}
